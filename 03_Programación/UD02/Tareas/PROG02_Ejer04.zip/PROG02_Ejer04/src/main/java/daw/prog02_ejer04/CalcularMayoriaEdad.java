package daw.prog02_ejer04;


public class CalcularMayoriaEdad {

    public static void main(String[] args) {
        
        //Inicializo la variable edad
        int edad=50;
        
        //Creo una variable con el número 18 
        int mayoriaEdad=18;
        
        //Utilizo un ternario para comparar la edad introducida con los 18 años
        String resultado=(edad>=mayoriaEdad)? "Eres mayor de edad": "Eres menor de edad";
        
        //Imprimo por consola
        System.out.println(resultado);
        
    }
    
}
