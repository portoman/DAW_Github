package daw.prog02_ejer08;

import java.text.DecimalFormat;

public class PorcentajeAlumnos {

    public static void main(String[] args) {

        //Declaro e inicializo las variables
        double alumPROG = 50;
        double alumED = 45;
        double alumBD = 37;

        //Calculo el total
        double totalAlum = alumPROG + alumED + alumBD;

        //Calculo los porcentajes
        double porcenPROG = alumPROG / totalAlum * 100;
        double porcenED = alumED / totalAlum * 100;
        double porcenBD = alumBD / totalAlum * 100;

        //Utilizo la clase DecimalFormat
        DecimalFormat df = new DecimalFormat("#0.0");

        //Imprimo el resultado por pantalla
        System.out.print("El porcentaje de alumnos de Programación es: " + df.format(porcenPROG) + "\n"
                + "El porcentaje de alumnos de Entornos de Desarrollo es: " + df.format(porcenED) + "\n"
                + "El porcentaje de alumnos de Base de datos es: " + df.format(porcenBD) + "\n"
                + "El total de alumnos es: " + totalAlum
        );

    }

}
