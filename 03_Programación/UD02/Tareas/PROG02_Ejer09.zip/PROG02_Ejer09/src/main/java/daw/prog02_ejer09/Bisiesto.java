package daw.prog02_ejer09;

public class Bisiesto {

    public static void main(String[] args) {
        
        //Declaro un año
        double año=2000;
        
        //Utilizo un ternario aplicando las condiciones
        String resultado=((año%4==0 &&año%100!=0)||año%400==0)? "El año es bisiesto": "El año no es bisiesto";
        
        //Imprimo valor por pantalla:
        System.out.println(resultado);
        
    }
    
}
