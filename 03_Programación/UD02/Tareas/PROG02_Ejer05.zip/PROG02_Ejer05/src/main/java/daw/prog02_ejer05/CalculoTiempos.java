package daw.prog02_ejer05;


public class CalculoTiempos {

    public static void main(String[] args) {

        //Declaro e inicializo la variable segundos
        int segundo = 30000;

        //Declaro las siguientes constantes
        final double SEGUNDOS_MINUTO = 60;
        final double SEGUNDOS_HORA = 3600;
        final double SEGUNDOS_DIA = 86400;

        //Operaciones
        double minutos = segundo / SEGUNDOS_MINUTO;
        double horas = segundo / SEGUNDOS_HORA;
        double dias = segundo / SEGUNDOS_DIA;

        //Creo una cadena para almacenar el resultado
        String resultadoTexto = segundo + " segundos son: " + minutos + " minutos, " + horas + " horas y " + dias + " dias";

        //Imprimo por consola
        System.out.println(resultadoTexto);
    }

}
