package daw.prog02_ejer07;

import java.text.DecimalFormat;

public class Ecuacion {

    public static void main(String[] args) {
        
        //Declaro las variables
        double c1=7;
        double c2=6000;
        double x;
        
        //La fórmula para resolver la ecuación (C1x+C2=0) sería la de abajo:
        x=-c2/c1;
        
        //Para restringir el número de decimales a 4 utilizo la clase DecimalFormat, realizando lo siguiente
        DecimalFormat df=new DecimalFormat("#0.0000");
        
        //Imprimo el resultado por pantalla
        System.out.println("El resultado de la ecuación es: x= "+df.format(x));
        
    }
    
}
