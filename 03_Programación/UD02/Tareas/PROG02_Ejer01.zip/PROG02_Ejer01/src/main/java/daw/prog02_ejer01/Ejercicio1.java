package daw.prog02_ejer01;

import java.util.Date;

public class Ejercicio1 {
    
    public enum Sexos {V,M};
    public static void main(String[] args) {

        /* 
        1. Valor máximo no modificable: 5000.
            - Elijo el tipo primitivo short ya que el valor de 50000 se ajusta al rango de valores que puede soportar short con sus 2 bytes
            - Como no va se va a modificar lo declaro constante con la palabra 'final' y como buena práctica para definir constantes 
              declaro el indentificador en mayúsculas
        */
        final short VALORMAX=5000;
        
        /*
        2.Si el nuevo empleado tiene carnet de conducir o no.
            - Elijo el tipo primitivo booleano ya que solo existen dos posibles valores: verdadero o falso
            - Utilizo la tipografía camelCase en esta y todas las variables como buena práctica
        */
        
        boolean carnetConducir=true;
        
        /* 
        3.Un mes del año en formato numérido y como cadena.
            - Elijo String por que tiene que ser cadena y elijo mayo que corresponde al mes número 5
        */
        
        String mayo="5";
        
        /* 4.El nombre y apellidos de una persona.
            - Escojo String para representarlo en una cadena. Declaro e inicializao con mi nombre
        */
        String nombreApellidos="Jesús Alfonso Porto Bujía";
        
        /* 5.Sexo: con dos valores posibles 'V' o 'M'.
            - Elijo el tipo enumerado porque la variable está restringida a 2 valores posibles.
            Para ello declaro la variable enum Sexos fuera del método principal con los 2 posibles valores 'V' y 'M'
            y dentro del método declaro la variable 'sexo' y le asigno el valor 'V'
        */
        Sexos sexo=Sexos.V;
        
        /* 6.Milisegundos transcurridos desde el 01/01/1970 hasta nuestros días.
            - Primero calculo el valor para saber el número de digitos:
                -Importo la clase Date que es adecuada para trabajar con fechas
                - Declaro una nueva clase Date llamada fecha
                - El método .getTime() justo calcula el número de segundos que hay entre 01/01/1970 y hoy siendo: 1633518301287
            -Escojo el tipo long por es el único tipo primitivo de números enteros que lo puede soportar    
        */
        
        
        Date fecha=new Date();
        long milisegundos=fecha.getTime();
        
        /* 7.Saldo de una cuenta bancaria.
            - Escojo tipo double porque es el dato primitivo de coma flotante más recomendo de usar,
            ya que es una forma de asegurarse que se produzcan menos errores
        */
        
        double saldo=15478.89;
        
        /* 8.Distancia en kms desde la Tierra a Júpiter.
            - Tiene una distancia de 588000000 km, por lo que escojo el tipo de dato int, ya que es el que más se ajusta 
        */
        
        int distTiJu=588000000;
        
        //Muestro el valor de todas las variables sin usar println
        
        System.out.print("1. Valor máximo: "+VALORMAX+"\n"+
                           "2. Carnet de conducir: "+carnetConducir+"\n"+
                           "3. Número mes mayo: "+mayo+"\n"+
                           "4. Nombre y apellido: "+nombreApellidos+"\n"+
                           "5. Sexo: "+sexo+"\n"+
                           "6. Milisegundos: "+milisegundos+"\n"+
                           "7. Saldo: "+saldo+"\n"+
                           "8. Distancia de Tierra a Jupiter en km: "+distTiJu+"\n");
    }
    
}
