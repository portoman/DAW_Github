package daw.prog02_ejer06;

public class RazasPerro {

    public enum Raza{Mastín, Terrier, Bulldog, Pekines, Caniche, Galgo};
    
    public static void main(String[] args) {
        
        Raza var1=Raza.Terrier;
        Raza var2=Raza.Mastín;
        
        boolean resultado=var1==var2;
        System.out.println("El resultado de comparar var1 y var2 es: "+resultado);
        
        
        //Calculo la cantidad de valores que contiene, con los siguientes métodos
        int numValores=Raza.values().length;
        System.out.println("Cantidad de valores: "+numValores);
        
        
        //Para saber la posición uso el método de abajo (Las posiciones empiezan en el número cero)
        int posicionGalgo=Raza.Galgo.ordinal();
        
        System.out.println("La posición de la raza galgo es: "+posicionGalgo);
        
        //Abajo las posiciones de las variables creadas
        int posicionVar1=var1.ordinal();
        System.out.println("La posición de la var1 es: "+posicionVar1);
        
        int posicionVar2=var2.ordinal();
        System.out.println("La posición de la var2 es: "+posicionVar2);
        
    }
    
}
